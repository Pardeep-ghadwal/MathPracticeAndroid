# Math Practice Android app

This is an Android Studio project that packages the supplied Math Practice HTML as an offline Android app using a native Android WebView.

## Build the APK
1. Install the latest stable Android Studio.
2. Open this folder (`MathPracticeAndroid`) in Android Studio.
3. Allow Gradle sync to complete. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and compile SDK 35; Android Studio may prompt you to install SDK 35.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.

## App details
- App name: Math Practice
- Application ID: `com.pardeep.mathpractice`
- Minimum Android version: Android 6.0 (API 23)
- HTML, CSS and JavaScript are bundled locally; no internet permission is requested.

For a Play Store release, create a signed app bundle/APK from **Build > Generate Signed Bundle / APK**.
