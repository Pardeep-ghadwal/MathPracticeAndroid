# Build the APK using only your Android phone

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. In your phone browser, sign in to GitHub and create a **public or private repository** named `MathPracticeAndroid`.
2. Upload the *contents* of this project folder to the repository, keeping the folder structure. In particular, `.github/workflows/build-apk.yml` must be present at the repository root under `.github/workflows/`.
   - If GitHub's mobile upload page hides dot-folders, switch your browser to **Desktop site** and upload `.github` as well.
3. Open the repository's **Actions** tab. Select **Build Math Practice APK** and tap **Run workflow** if it has not started automatically after the upload.
4. Wait for the workflow to finish with a green check mark.
5. Open that completed run, scroll to **Artifacts**, and download `MathPractice-debug-apk`.
6. Extract the downloaded artifact ZIP on your phone. Tap `app-debug.apk` to install it. If Android asks, allow your browser or file manager to install unknown apps.

The APK is a debug build for personal installation, not a Play Store-signed release. The app's HTML is bundled locally and works offline.
